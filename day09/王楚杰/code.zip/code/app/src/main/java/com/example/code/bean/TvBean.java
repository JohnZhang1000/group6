package com.example.code.bean;

import java.util.List;

public class TvBean {
    /**
     * status : {"statusCode":100,"message":"请求成功！","serverTime":"2020-08-04 16:34:00"}
     * data : {"total":253,"list":[{"id":0,"reptileArticleID":0,"createTime":"2020-08-04 14:05:01","detailUrl":"","status":0,"title":"入坑指南汉服回归，入坑需谨慎","content":"","cover":"","type":0,"commID":1979,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202008/a4ac6ab37f3540e6a1851d00b91c24a3.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/eb7626adb6a24a63b2f3951d4e211ea5.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/5526d5270d834745a231b61e79eef4ac.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-08-04 14:03:37","detailUrl":"","status":0,"title":"萌新来看，穿汉服上街要注意哪些问题?你一定不知道","content":"","cover":"","type":0,"commID":1978,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202008/6caed7330c014d44a95f5db75bd88c26.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-08-04 14:02:54","detailUrl":"","status":0,"title":"国外时装就是\u201c奇装异服\u201d，仙气的汉服才是时尚，颜值是入坑标准","content":"","cover":"","type":0,"commID":1977,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-08-04 11:07:02","detailUrl":"","status":0,"title":"宋制汉服穿搭，优雅灵动","content":"","cover":"","type":0,"commID":1972,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202008/e9507ee724834bde829310ef98877585.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/76edf34d334a486a9fb095970f72d4c6.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/9f47e0eb489e456199ce52a21782a500.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-31 10:03:46","detailUrl":"","status":0,"title":"国风大赏汉服美女最全返图，选出你最爱的小姐姐","content":"","cover":"","type":0,"commID":1960,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/e7b4b5dbd5254390aa21081fa8a9262b.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-30 16:20:30","detailUrl":"","status":0,"title":"三十六雨汉服私影","content":"","cover":"","type":0,"commID":1959,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-29 09:26:22","detailUrl":"","status":0,"title":"清女装是汉服吗？从中国人物画看汉服体系的中断","content":"","cover":"","type":0,"commID":1954,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/38b9c22fe0ee4fa18c3c61a3ff8bb07a.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/c5abd7aa953246faa3ca93f2b0226957.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/8cc87591cabe4f2e9a8114fc899baf12.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-29 09:20:42","detailUrl":"","status":0,"title":"穿汉服、看表演、淘礼品,杨浦这里将成为这个暑期档里最有国风味的地方!","content":"","cover":"","type":0,"commID":1953,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/777ecaefc37c479f9ce1683449de4703.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-29 09:15:52","detailUrl":"","status":0,"title":"盘点那些经常\u201c撞衫\u201d的汉服，基本人手一件，你拥有几套？","content":"","cover":"","type":0,"commID":1952,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-29 09:12:13","detailUrl":"","status":0,"title":"复兴汉服有意义吗？穿着汉服上街，算不算复兴汉服？","content":"","cover":"","type":0,"commID":1951,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/d70dc8bf108f4eff8131aff278880fe9.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/dea6b863e7554294b105c5ee00056c23.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/cd7a543bbf6849099a5f1f19a8a3bb0f.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:14:55","detailUrl":"","status":0,"title":"汉服小仙女：洧之外，洵訏且乐","content":"","cover":"","type":0,"commID":1947,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/239f2ccdd50c4f99b33d30c0f8967908.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:14:26","detailUrl":"","status":0,"title":"汉服小仙女：倚栏红袖卷轻纱","content":"","cover":"","type":0,"commID":1946,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:11:58","detailUrl":"","status":0,"title":"买了这么多汉服，你知道交窬裙是什么吗？它和襦裙的区别是？","content":"","cover":"","type":0,"commID":1945,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/61040d4fa61e4be3be8d0d32b4327cdc.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/3db83e179f894fda9b3cb3d40b7d268a.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/8c6a830f715f4cde806e165c923efdd3.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:05:30","detailUrl":"","status":0,"title":"为什么越来越多人反感\u201c汉服圈\u201d？","content":"","cover":"","type":0,"commID":1944,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/2e752f98fc514081ac5db6490b6d21f3.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:02:35","detailUrl":"","status":0,"title":"汉服走红的背后，藏着中国年轻人日渐强烈的文化自信","content":"","cover":"","type":0,"commID":1943,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-17 14:44:19","detailUrl":"","status":0,"title":"同袍将汉服变成婚纱，回眸一笑百媚生！网友直呼：嫁给我吧！","content":"","cover":"","type":0,"commID":1932,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/3032a2f404554be1aa5c652675228f0e.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/fe072cb4a2c04f0db0f888d449ef9ca1.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/c889dca89fd04380aeabfdf6bbb471ac.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-17 14:43:22","detailUrl":"","status":0,"title":"文物是\u201c鱼\u201d汉服要\u201c渔\u201d后者不随前者存亡","content":"","cover":"","type":0,"commID":1931,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/00b25c8184a444c397494d400a0b5d39.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-17 14:41:57","detailUrl":"","status":0,"title":"【汉服】仿，唐舞女俑双环髻","content":"","cover":"","type":0,"commID":1930,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-17 14:40:11","detailUrl":"","status":0,"title":"绝美侧颜杀汉服小姐姐，是古画中走出的美人吗？","content":"","cover":"","type":0,"commID":1929,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/5b78fa77bd5843dfa5203a9303d3ada2.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/77e620f3fefa46e5a819d75e8d8460c5.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/ad8ccb30b7e54cb79e81b12d666f8289.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-15 09:27:46","detailUrl":"","status":0,"title":"白衣飘飘古装美女汉服摄影雪中仙","content":"","cover":"","type":0,"commID":1927,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/8bfa17f0eb564a03ae9ca88086e3f383.jpg?imageView2/2/format/jpg"}]}],"comTotal":0}
     */

    private StatusBean status;
    private DataBean data;

    public StatusBean getStatus() {
        return status;
    }

    public void setStatus(StatusBean status) {
        this.status = status;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class StatusBean {
        /**
         * statusCode : 100
         * message : 请求成功！
         * serverTime : 2020-08-04 16:34:00
         */

        private int statusCode;
        private String message;
        private String serverTime;

        public int getStatusCode() {
            return statusCode;
        }

        public void setStatusCode(int statusCode) {
            this.statusCode = statusCode;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getServerTime() {
            return serverTime;
        }

        public void setServerTime(String serverTime) {
            this.serverTime = serverTime;
        }
    }

    public static class DataBean {
        /**
         * total : 253
         * list : [{"id":0,"reptileArticleID":0,"createTime":"2020-08-04 14:05:01","detailUrl":"","status":0,"title":"入坑指南汉服回归，入坑需谨慎","content":"","cover":"","type":0,"commID":1979,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202008/a4ac6ab37f3540e6a1851d00b91c24a3.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/eb7626adb6a24a63b2f3951d4e211ea5.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/5526d5270d834745a231b61e79eef4ac.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-08-04 14:03:37","detailUrl":"","status":0,"title":"萌新来看，穿汉服上街要注意哪些问题?你一定不知道","content":"","cover":"","type":0,"commID":1978,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202008/6caed7330c014d44a95f5db75bd88c26.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-08-04 14:02:54","detailUrl":"","status":0,"title":"国外时装就是\u201c奇装异服\u201d，仙气的汉服才是时尚，颜值是入坑标准","content":"","cover":"","type":0,"commID":1977,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-08-04 11:07:02","detailUrl":"","status":0,"title":"宋制汉服穿搭，优雅灵动","content":"","cover":"","type":0,"commID":1972,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202008/e9507ee724834bde829310ef98877585.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/76edf34d334a486a9fb095970f72d4c6.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/9f47e0eb489e456199ce52a21782a500.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-31 10:03:46","detailUrl":"","status":0,"title":"国风大赏汉服美女最全返图，选出你最爱的小姐姐","content":"","cover":"","type":0,"commID":1960,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/e7b4b5dbd5254390aa21081fa8a9262b.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-30 16:20:30","detailUrl":"","status":0,"title":"三十六雨汉服私影","content":"","cover":"","type":0,"commID":1959,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-29 09:26:22","detailUrl":"","status":0,"title":"清女装是汉服吗？从中国人物画看汉服体系的中断","content":"","cover":"","type":0,"commID":1954,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/38b9c22fe0ee4fa18c3c61a3ff8bb07a.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/c5abd7aa953246faa3ca93f2b0226957.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/8cc87591cabe4f2e9a8114fc899baf12.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-29 09:20:42","detailUrl":"","status":0,"title":"穿汉服、看表演、淘礼品,杨浦这里将成为这个暑期档里最有国风味的地方!","content":"","cover":"","type":0,"commID":1953,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/777ecaefc37c479f9ce1683449de4703.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-29 09:15:52","detailUrl":"","status":0,"title":"盘点那些经常\u201c撞衫\u201d的汉服，基本人手一件，你拥有几套？","content":"","cover":"","type":0,"commID":1952,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-29 09:12:13","detailUrl":"","status":0,"title":"复兴汉服有意义吗？穿着汉服上街，算不算复兴汉服？","content":"","cover":"","type":0,"commID":1951,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/d70dc8bf108f4eff8131aff278880fe9.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/dea6b863e7554294b105c5ee00056c23.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/cd7a543bbf6849099a5f1f19a8a3bb0f.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:14:55","detailUrl":"","status":0,"title":"汉服小仙女：洧之外，洵訏且乐","content":"","cover":"","type":0,"commID":1947,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/239f2ccdd50c4f99b33d30c0f8967908.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:14:26","detailUrl":"","status":0,"title":"汉服小仙女：倚栏红袖卷轻纱","content":"","cover":"","type":0,"commID":1946,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:11:58","detailUrl":"","status":0,"title":"买了这么多汉服，你知道交窬裙是什么吗？它和襦裙的区别是？","content":"","cover":"","type":0,"commID":1945,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/61040d4fa61e4be3be8d0d32b4327cdc.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/3db83e179f894fda9b3cb3d40b7d268a.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/8c6a830f715f4cde806e165c923efdd3.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:05:30","detailUrl":"","status":0,"title":"为什么越来越多人反感\u201c汉服圈\u201d？","content":"","cover":"","type":0,"commID":1944,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/2e752f98fc514081ac5db6490b6d21f3.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-28 09:02:35","detailUrl":"","status":0,"title":"汉服走红的背后，藏着中国年轻人日渐强烈的文化自信","content":"","cover":"","type":0,"commID":1943,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-17 14:44:19","detailUrl":"","status":0,"title":"同袍将汉服变成婚纱，回眸一笑百媚生！网友直呼：嫁给我吧！","content":"","cover":"","type":0,"commID":1932,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/3032a2f404554be1aa5c652675228f0e.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/fe072cb4a2c04f0db0f888d449ef9ca1.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/c889dca89fd04380aeabfdf6bbb471ac.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-17 14:43:22","detailUrl":"","status":0,"title":"文物是\u201c鱼\u201d汉服要\u201c渔\u201d后者不随前者存亡","content":"","cover":"","type":0,"commID":1931,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/00b25c8184a444c397494d400a0b5d39.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-17 14:41:57","detailUrl":"","status":0,"title":"【汉服】仿，唐舞女俑双环髻","content":"","cover":"","type":0,"commID":1930,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-17 14:40:11","detailUrl":"","status":0,"title":"绝美侧颜杀汉服小姐姐，是古画中走出的美人吗？","content":"","cover":"","type":0,"commID":1929,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/5b78fa77bd5843dfa5203a9303d3ada2.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/77e620f3fefa46e5a819d75e8d8460c5.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202007/ad8ccb30b7e54cb79e81b12d666f8289.jpg?imageView2/2/format/jpg"}]},{"id":0,"reptileArticleID":0,"createTime":"2020-07-15 09:27:46","detailUrl":"","status":0,"title":"白衣飘飘古装美女汉服摄影雪中仙","content":"","cover":"","type":0,"commID":1927,"sourceStr":"","author":"","cagetory":"","listImages":"","qiYuId":"","keyword":"","filePathList":[{"filePath":"http://qiniu2.xiguangtech.com/202007/8bfa17f0eb564a03ae9ca88086e3f383.jpg?imageView2/2/format/jpg"}]}]
         * comTotal : 0
         */

        private int total;
        private int comTotal;
        private List<ListBean> list;

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getComTotal() {
            return comTotal;
        }

        public void setComTotal(int comTotal) {
            this.comTotal = comTotal;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            /**
             * id : 0
             * reptileArticleID : 0
             * createTime : 2020-08-04 14:05:01
             * detailUrl :
             * status : 0
             * title : 入坑指南汉服回归，入坑需谨慎
             * content :
             * cover :
             * type : 0
             * commID : 1979
             * sourceStr :
             * author :
             * cagetory :
             * listImages :
             * qiYuId :
             * keyword :
             * filePathList : [{"filePath":"http://qiniu2.xiguangtech.com/202008/a4ac6ab37f3540e6a1851d00b91c24a3.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/eb7626adb6a24a63b2f3951d4e211ea5.jpg?imageView2/2/format/jpg"},{"filePath":"http://qiniu2.xiguangtech.com/202008/5526d5270d834745a231b61e79eef4ac.jpg?imageView2/2/format/jpg"}]
             */

            private int id;
            private int reptileArticleID;
            private String createTime;
            private String detailUrl;
            private int status;
            private String title;
            private String content;
            private String cover;
            private int type;
            private int commID;
            private String sourceStr;
            private String author;
            private String cagetory;
            private String listImages;
            private String qiYuId;
            private String keyword;
            private List<FilePathListBean> filePathList;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getReptileArticleID() {
                return reptileArticleID;
            }

            public void setReptileArticleID(int reptileArticleID) {
                this.reptileArticleID = reptileArticleID;
            }

            public String getCreateTime() {
                return createTime;
            }

            public void setCreateTime(String createTime) {
                this.createTime = createTime;
            }

            public String getDetailUrl() {
                return detailUrl;
            }

            public void setDetailUrl(String detailUrl) {
                this.detailUrl = detailUrl;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getCover() {
                return cover;
            }

            public void setCover(String cover) {
                this.cover = cover;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public int getCommID() {
                return commID;
            }

            public void setCommID(int commID) {
                this.commID = commID;
            }

            public String getSourceStr() {
                return sourceStr;
            }

            public void setSourceStr(String sourceStr) {
                this.sourceStr = sourceStr;
            }

            public String getAuthor() {
                return author;
            }

            public void setAuthor(String author) {
                this.author = author;
            }

            public String getCagetory() {
                return cagetory;
            }

            public void setCagetory(String cagetory) {
                this.cagetory = cagetory;
            }

            public String getListImages() {
                return listImages;
            }

            public void setListImages(String listImages) {
                this.listImages = listImages;
            }

            public String getQiYuId() {
                return qiYuId;
            }

            public void setQiYuId(String qiYuId) {
                this.qiYuId = qiYuId;
            }

            public String getKeyword() {
                return keyword;
            }

            public void setKeyword(String keyword) {
                this.keyword = keyword;
            }

            public List<FilePathListBean> getFilePathList() {
                return filePathList;
            }

            public void setFilePathList(List<FilePathListBean> filePathList) {
                this.filePathList = filePathList;
            }

            public static class FilePathListBean {
                /**
                 * filePath : http://qiniu2.xiguangtech.com/202008/a4ac6ab37f3540e6a1851d00b91c24a3.jpg?imageView2/2/format/jpg
                 */

                private String filePath;

                public String getFilePath() {
                    return filePath;
                }

                public void setFilePath(String filePath) {
                    this.filePath = filePath;
                }
            }
        }
    }
}
