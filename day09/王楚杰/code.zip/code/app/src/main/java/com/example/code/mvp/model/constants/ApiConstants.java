package com.example.code.mvp.model.constants;

/**
 * 常量类 存放所有接口
 */
public class ApiConstants {
    public static String sUrl = "http://cdwan.cn:7000/tongpao/";
}